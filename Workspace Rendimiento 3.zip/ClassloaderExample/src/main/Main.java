package main;

import com.util.math.Factorial;


public class Main {
	
	
	public static void main(String[] args) {
		 
		System.out.println("Practica con los classloaders");
		
		System.out.println("Factorial n=0 => "+Factorial.factorial(0));
		System.out.println("Factorial n=1 => "+Factorial.factorial(1));
		System.out.println("Factorial n=2 => "+Factorial.factorial(2));
		System.out.println("Factorial n=3 => "+Factorial.factorial(3));
		System.out.println("Factorial n=4 => "+Factorial.factorial(4));
		System.out.println("Factorial n=5 => "+Factorial.factorial(5));
	}
}
