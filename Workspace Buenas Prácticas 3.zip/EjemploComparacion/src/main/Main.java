package main;

public class Main {

	public static void main(String[] args) {
		
		
//		String cadena1="Hola Mundo";
//		String cadena2="Hola mundo";
// 		
//		if (cadena1 == cadena2){
//			System.out.println("== Son iguales");
//		}else{
//			System.out.println("== Son diferentes");
//		}
// 
//		if (cadena1!=null && cadena1.equals(cadena2)){
//			System.out.println("equals() Son iguales");
//		}else{
//			System.out.println("equals() Son diferentes");
//		}
//		
//		if (cadena1!=null && cadena1.equalsIgnoreCase(cadena2)){
//			System.out.println("equalsIgnoreCase() Son iguales");
//		}else{
//			System.out.println("equalsIgnoreCase() Son diferentes");
//		}
		
		
//		
		String cadena11=new String("Hola Mundo");
		String cadena12=new String("Hola MUNDO");
////
////		
		if (cadena11 == cadena12){
			System.out.println("11==12 Son iguales");
		}else{
			System.out.println("11==12 Son diferentes");
		}
//		
		if (cadena11!=null && cadena11.equals(cadena12)){
			System.out.println("11.equals(12) Son iguales");
		}
//		
//		
		if (cadena11!=null && cadena11.equalsIgnoreCase(cadena12)){
			System.out.println("11.equalsIgnoreCase(12) Son iguales");
		}
		
	}

}
